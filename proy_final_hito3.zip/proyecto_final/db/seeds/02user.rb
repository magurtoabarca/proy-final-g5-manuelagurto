User.create(email: "manuel@deco.com", username: "manuel", password_digest: "1234567", admin: true)
User.create(email: "cristina@deco.com", username: "cristina", password_digest: "1234567")
User.create(email: "gerardoa@deco.com", username: "gerardo", password_digest: "1234567")
