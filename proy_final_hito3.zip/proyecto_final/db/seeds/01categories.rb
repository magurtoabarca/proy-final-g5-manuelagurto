Category.create(name: "baja")
Category.create(name: "media")
Category.create(name: "alta")
Category.create(name: "mayor")