figura1:
  title: Figura-01
  description: Fiesta figura
  price: 100
  category: baja
  user: gerardo

figura2:
  title: Figura-02
  description: Fiesta figura
  price: 200
  category: media
  user: cristina
