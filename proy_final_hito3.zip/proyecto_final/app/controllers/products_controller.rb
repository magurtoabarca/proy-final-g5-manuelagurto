class ProductsController < ApplicationController
    skip_before_action :protect_pages, only: [:index, :show]

    def index
        @categories = Category.all.order(name: :asc).load_async
        @products = Product.all.with_attached_photo.order(created_at: :desc).load_async
        if params[:category_id]
            @products = @products.where(category_id: params[:category_id])
        end

        @pagy, @products = pagy_countless(@products, items:10)
    end

    def show
        product
    end

    def new
        @product = Product.new
    end

    def create
        @product = Product.new(product_params)
        if @product.save
            redirect_to products_path, notice: 'Producto creado correctamente'
        else
            render :new, status: :unprocessable_entity
        end
       
    end

    def edit
        authorize! product
        
    end

    def update
        authorize! product
          if product.update(product_params)
            redirect_to products_path, notice: 'Producto actualizado correctamente'
        else
            render :edit, status: :unprocessable_entity
        end
    end

    def destroy
        authorize! product
        product.destroy
        redirect_to products_path, notice: 'Producto eliminado correctamente', status: :see_other
    end



    private

    def product_params
        params.require(:product).permit(:title, :description, :price, :photo, :category_id)
    end

    def product
        @product = Product.find(params[:id])
    end

end
