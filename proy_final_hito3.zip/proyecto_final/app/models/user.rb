class User < ApplicationRecord
    has_secure_password
    validates :email, presence: true, uniqueness: true
    validates :username, presence: true, uniqueness: true, length: { in: 3..15}, format: {with: /\A[a-z0-9A-Z]+\z/, message: :invalid} 
    validates :password, length: { minimum: 6 }

    has_many :products, dependent: :destroy
    before_save :downcase_attributes 

    private

    def downcase_attributes
        self.username = username.downcase
        self.email = email.downcase


    end

end
