require 'test_helper'

class ProductsControllerTest < ActionDispatch::IntegrationTest

    test 'render a list of products' do
        get products_path 
        assert_response :success
        assert_select '.product', 10
        assert_select '.category', 4
    end

    test 'render a list of products filtered by category' do
        get products_path(category_id: categories(:alta).id)
        assert_response :success
        assert_select '.product', 9

    end

    test 'render a detailed product page' do
        get product_path(products(:figura1))
        assert_response :success
        assert_select '.title', 'Figura-01'
        assert_select '.description', 'Fiesta figura'
        assert_select '.price', '100'
       
    end

    test 'render a new product form' do
        get new_product_path
        assert_response :success
        assert_select 'form'
    end

    test 'allow to create a new product' do
        post products_path, params: {
            product: {
                title: 'Figura-03',
                description: 'Fiesta figura',
                price: 300,
                category_id: categories(:alta).id
            }
        }
        assert_redirected_to products_path
        assert_equal flash[:notice], 'Producto creado correctamente'
    end

    test 'does not allow to create a new product with empty fileds' do
        post products_path, params: {
            product: {
                title: '',
                description: 'Fiesta figura',
                price: 400
              
            }
        }
        assert_response :unprocessable_entity
    end

    test 'render an edit product form' do
        get edit_product_path(products(:figura2))
        assert_response :success
        assert_select 'form'
    end

    test 'allow to update a product' do
        patch product_path(products(:figura2)), params: {
            product: {
                price: 250
            }
        }
        assert_redirected_to products_path
        assert_equal flash[:notice], 'Producto actualizado correctamente'
    end

    test 'can delete products' do
        assert_difference('Product.count', -1) do
            delete product_path(products(:figura2))
        end

        assert_redirected_to products_path
        assert_equal flash[:notice], 'Producto eliminado correctamente'
    end
end
